#ifndef UNIT_TEST
#define UNIT_TEST


/* test de l'affichage de Cst */
void test_affiche();

/* test de la simplifiacation de Cst */
void test_simplifie_Cst();

/* Test du sujet */
void test_sujet();


#endif 