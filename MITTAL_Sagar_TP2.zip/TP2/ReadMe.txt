Voir ReadMe.txt dans LIVRABLE_1 ou LIVRABLE_2

Vous pourvez faire make dans LIVRABLE_1 et LIVRABLE_2

