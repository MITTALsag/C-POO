Pour l'exercice 1 et 2 voir LIVRABLE_1 et pour la partie graphique voir LIVRALBLE_2.


Dans le LIVRABLE_1 et LIVRABLE_2 vous pouvez faire make.

Dans LIVRABLE_1 il y a unit_test_Grille.cpp pour les tests unitaires de la calsse Grille. 
Et Livrable1.cpp pour les test de la classe Jeu. (lancer Livrable1 et laissez-vous gider)


Pour LIVRABLE_2 il n'y a que un seul exectutable Livrable2.cpp de la partie graphique.
J'ai mis la grille en mode disque comment dans l'enoncé mais il y a une fonction pour une grille avec des rectangle.
Laissez vous aussi guider avec les boutons.


Merci.