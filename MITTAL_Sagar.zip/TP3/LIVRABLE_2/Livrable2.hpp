#ifndef Livrable2_HPP
#define Livrable2_HPP
#include <wx/wx.h>


class MyApp : public wxApp {
public:
    bool OnInit() override;
};

#endif