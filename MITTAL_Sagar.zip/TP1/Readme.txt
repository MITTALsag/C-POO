Pour compiler il faut aller dans une des 3 dossiers Livrable1, Livrable2 ou Livrable3.
Dedans il vous suffit de faire la commande make puis de lancer l'éxécutable par la commande ./Livrable1, ./Livrable2 ou ./Livrable3

PS :
Pour Livrable3 il faut mettre en argument : 
"runTests", "factorial_Entier", "factorial_int", "Un" ou "Vn".