#include <iostream>
#include "test_Livrable1.hpp"

int main() {
    
    test_methodes();
    test_methodes_opp();
    return 0;
}
