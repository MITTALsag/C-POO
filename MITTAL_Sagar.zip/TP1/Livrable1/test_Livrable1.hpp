#ifndef __LIVRABLE1_HPP__
#define __LIVRABLE1_HPP__

//test les methode de constructeur, d'approx, de simplifie de la classe Rationnel
void test_methodes(void);


// test toutes les méthodes d'operation de la classe Rationnel
void test_methodes_opp(void);

#endif